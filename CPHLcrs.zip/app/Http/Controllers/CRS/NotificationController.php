<?php

namespace App\Http\Controllers\crs;

use App\Http\Controllers\Controller;
use App\Models\CRS\notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        notification::where('id', $id)->update(['seen' => 'Yes']);
        $notifications = notification::leftJoin('facilities', 'notifications.facility_id', '=', 'facilities.id')
        ->leftJoin('users', 'notifications.user_id', '=', 'users.id')
        ->select('notifications.created_at as date', 'notifications.id as nid', 'body', 'subject', 'facility_name', 'name', 'first_name', 'avatar')
        ->where('notifications.id', $id)->get();

        return view('crs.vewNotification', compact('notifications'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
